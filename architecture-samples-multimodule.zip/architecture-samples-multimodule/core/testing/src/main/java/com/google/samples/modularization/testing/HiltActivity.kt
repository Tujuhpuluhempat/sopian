package com.google.samples.modularization.testing

import androidx.activity.ComponentActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class HiltActivity: ComponentActivity()
